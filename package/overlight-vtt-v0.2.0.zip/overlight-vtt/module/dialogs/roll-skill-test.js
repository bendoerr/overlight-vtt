import { OVERLIGHT_VIRTUES } from "../virtue.js";
import { OVERLIGHT_DIE_TYPES, OVERLIGHT_POOL_MODIFIERS, OverlightHand, OverlightSkillTest, } from "../roll.js";
import { OVERLIGHT_SKILLS } from "../skill.js";
import { OverlightSkillTestChat } from "../chats/roll-skill-test.js";
export class RollSkillTestDialog {
    constructor() {
        this.dialog = RollSkillTestDialog.getTemplate().then((content) => {
            return new Dialog({
                title: game.i18n.localize("overlight-vtt.dialog.roll-skill-test.title"),
                content: content,
                buttons: {
                    close: {
                        icon: '<i class="fas fa-times"></i>',
                        label: game.i18n.localize("overlight-vtt.dialog.roll-skill-test.close"),
                    },
                    roll: {
                        icon: '<i class="fas fa-check"></i>',
                        label: game.i18n.localize("overlight-vtt.dialog.roll-skill-test.roll"),
                        callback: (result) => {
                            const formData = new FormData(result[0].querySelector("#dice-pool-form"));
                            return this.handleResponse(formData);
                        },
                    },
                },
                default: "roll",
            }, {});
        });
    }
    static getTemplate() {
        return renderTemplate(RollSkillTestDialog.html, {
            virtues: OVERLIGHT_VIRTUES,
            skills: OVERLIGHT_SKILLS,
            die: OVERLIGHT_DIE_TYPES,
            modifiers: OVERLIGHT_POOL_MODIFIERS,
            defaults: {
                "virtue-die": "d6",
                "skill-die": "d6",
            },
        });
    }
    render() {
        return this.dialog.then((d) => d.render(true));
    }
    handleResponse(formData) {
        // Create a new test
        const test = new OverlightSkillTest(new OverlightHand("skill", "virtue", formData.get("virtue"), formData.get("virtue-die"), formData.get("virtue-mod"), "skill", formData.get("skill"), formData.get("skill-die"), formData.get("skill-mod"), formData.get("include-spirit") === "on"));
        // Roll the test
        test.hand.roll();
        // Send it to chat
        new OverlightSkillTestChat(test).send();
    }
}
RollSkillTestDialog.html = "systems/overlight-vtt/templates/dialogs/roll-skill-test.html";

//# sourceMappingURL=roll-skill-test.js.map
