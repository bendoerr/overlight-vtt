import { OVERLIGHT_DIE_TYPES, OVERLIGHT_POOL_MODIFIERS, OverlightHand, OverlightChromaTest, } from "../roll.js";
import { OVERLIGHT_SKILLS } from "../skill.js";
import { OverlightWealthTestChat } from "../chats/roll-wealth-test.js";
export class RollWealthTestDialog {
    constructor() {
        this.dialog = RollWealthTestDialog.getTemplate().then((content) => {
            return new Dialog({
                title: game.i18n.localize("overlight-vtt.dialog.roll-wealth-test.title"),
                content: content,
                buttons: {
                    close: {
                        icon: '<i class="fas fa-times"></i>',
                        label: game.i18n.localize("overlight-vtt.dialog.roll-skill-test.close"),
                    },
                    roll: {
                        icon: '<i class="fas fa-check"></i>',
                        label: game.i18n.localize("overlight-vtt.dialog.roll-skill-test.roll"),
                        callback: (result) => {
                            const formData = new FormData(result[0].querySelector("#dice-pool-form"));
                            return this.handleResponse(formData);
                        },
                    },
                },
                default: "roll",
            }, {});
        });
    }
    static getTemplate() {
        return renderTemplate(RollWealthTestDialog.html, {
            virtues: ["wealth"],
            skills: OVERLIGHT_SKILLS,
            die: OVERLIGHT_DIE_TYPES,
            modifiers: OVERLIGHT_POOL_MODIFIERS,
            defaults: {
                "virtue-die": "d6",
                "skill-die": "d6",
            },
        });
    }
    render() {
        return this.dialog.then((d) => d.render(true));
    }
    handleResponse(formData) {
        // Create a new test
        const test = new OverlightChromaTest(new OverlightHand("wealth", "virtue", formData.get("virtue"), formData.get("virtue-die"), formData.get("virtue-mod"), "skill", formData.get("skill"), formData.get("skill-die"), formData.get("skill-mod"), formData.get("include-spirit") === "on"));
        // Roll the test
        test.hand.roll();
        // Send it to chat
        new OverlightWealthTestChat(test).send();
    }
}
RollWealthTestDialog.html = "systems/overlight-vtt/templates/dialogs/roll-skill-test.html";

//# sourceMappingURL=roll-wealth-test.js.map
