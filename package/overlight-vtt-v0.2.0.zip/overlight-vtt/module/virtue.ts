export const OVERLIGHT_VIRTUES = ["wisdom", "logic", "compassion", "will", "vigor", "might"] as const;
export declare type OverlightVirtueType = "wisdom" | "logic" | "compassion" | "will" | "vigor" | "might" | "spirit";
