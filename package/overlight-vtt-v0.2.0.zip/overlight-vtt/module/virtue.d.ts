export declare type OverlightVirtueType = "wisdom" | "logic" | "compassion" | "will" | "vigor" | "might";
