export class OverlightCharacterActor extends Actor {
    constructor(data, options) {
        super(data, options);
    }
}

//# sourceMappingURL=character.js.map
