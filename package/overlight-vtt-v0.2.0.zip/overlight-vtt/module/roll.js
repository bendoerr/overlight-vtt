import { toDice3dColor } from "./utils.js";
export const OVERLIGHT_DIE_TYPES = ["untrained", "d4", "d6", "d8", "d10", "d12"];
export const OVERLIGHT_VIRTUE_DIE_TYPES = ["d6", "d8", "d10", "d12"];
export const OVERLIGHT_POOL_MODIFIERS = ["none", "raise", "lower", "d6", "d8", "d10", "d12"];
export class OverlightPool {
    constructor(type, name, die, modifier) {
        this.type = type;
        this.name = name;
        this.die = die;
        this.modifier = modifier;
        this.modifierSpill = false;
        if (type === "spirit") {
            if (modifier !== "none") {
                throw new Error("cannot modify spirit dice pool");
            }
            this.foundryRoll = new Roll("d4cs4");
        }
        else {
            if (modifier === "none") {
                if (die === "untrained") {
                    this.foundryRoll = new Roll("d6cs>=6");
                }
                else {
                    this.foundryRoll = new Roll("3" + die + "cs>=6");
                }
            }
            else {
                const [modDie, spill, modNum] = modifyDieType(die, modifier);
                this.modifierSpill = spill;
                if (die === "untrained") {
                    const numDie = 1 + modNum;
                    this.foundryRoll = new Roll(numDie + modDie + "cs>=6");
                }
                else {
                    const numDie = 3 + modNum;
                    if (die === modDie) {
                        this.foundryRoll = new Roll(numDie + die + "cs>=6");
                    }
                    else {
                        this.foundryRoll = new Roll("{" + modDie + "cs>=6" + ",2" + die + "cs>=6");
                    }
                }
            }
        }
    }
    roll() {
        if (this.rolled) {
            return this;
        }
        this.foundryRoll.roll();
        this.foundryRoll.dice.forEach((d) => {
            d.options["colorset"] = toDice3dColor(this.name);
        });
        this.rolled = true;
        return this;
    }
    successes() {
        if (this.rolled == false)
            throw new Error("pool has not been rolled");
        return this.foundryRoll.dice.reduce((successes, term) => successes + term.total, 0);
    }
    results() {
        if (this.rolled == false)
            throw new Error("pool has not been rolled");
        return this.foundryRoll.dice.flatMap((d) => {
            return d.results.map((o) => {
                return {
                    face: o["result"],
                    type: this.die !== "untrained" ? ("d" + d.faces) : this.die,
                    name: this.name,
                    pool: this.type,
                    success: o["success"],
                };
            });
        });
    }
    highestResult() {
        return this.results().reduce((highest, current) => {
            return current.face > highest.face ? current : highest;
        });
    }
    toFoundry() {
        return [this.foundryRoll];
    }
}
export class OverlightEmptyPool {
    constructor(type, name) {
        this.type = type;
        this.name = name;
    }
    highestResult() {
        return {
            face: 0,
            name: this.name,
            pool: this.type,
            success: false,
            type: "none",
        };
    }
    results() {
        return [];
    }
    roll() {
        return this;
    }
    successes() {
        return 0;
    }
    toFoundry() {
        return [];
    }
}
export class OverlightHand {
    constructor(type, poolOneType, poolOneName, poolOneDie, poolOneMod, poolTwoType, poolTwoName, poolTwoDie, poolTwoMod, includeSpirit) {
        this.type = type;
        this.poolOne = new OverlightPool(poolOneType, poolOneName, poolOneDie, poolOneMod);
        this.poolTwo = new OverlightPool(poolTwoType, poolTwoName, poolTwoDie, poolTwoMod);
        if (includeSpirit) {
            this.poolSpirit = new OverlightPool("spirit", "spirit", "d4", "none");
        }
        else {
            this.poolSpirit = new OverlightEmptyPool("spirit", "spirit");
        }
    }
    roll() {
        this.poolOne.roll();
        this.poolTwo.roll();
        this.poolSpirit.roll();
        return this;
    }
    results() {
        return this.poolOne.results().concat(this.poolTwo.results(), this.poolSpirit.results());
    }
    highestResult() {
        const r1 = this.poolOne.highestResult();
        const r2 = this.poolTwo.highestResult();
        return r1 < r2 ? r1 : r2;
    }
    successes() {
        return this.poolOne.successes() + this.poolTwo.successes();
    }
    toFoundry() {
        return this.poolOne.toFoundry().concat(this.poolTwo.toFoundry(), this.poolSpirit.toFoundry());
    }
}
/// See page 118
export function modifyDieType(type, modifier) {
    if (modifier === "none" || type === "d4") {
        return [type, false, 0];
    }
    if (modifier !== "raise" && modifier !== "lower") {
        return [modifier, false, 0];
    }
    switch (type) {
        case "untrained":
            return modifier === "raise" ? ["d4", false, 1] : ["d4", false, 0];
        case "d6":
            return modifier === "raise" ? ["d8", false, 0] : ["d6", false, -1];
        case "d8":
            return modifier === "raise" ? ["d10", false, 0] : ["d6", false, 0];
        case "d10":
            return modifier === "raise" ? ["d12", false, 0] : ["d8", false, 0];
        case "d12":
            return modifier === "raise" ? ["d12", true, 0] : ["d10", false, 0];
    }
}
export class OverlightSkillTest {
    constructor(hand) {
        this.hand = hand;
    }
    result() {
        this.hand.roll();
        const result = {
            successes: this.hand.successes(),
            successesRaw: this.hand.successes(),
            gameResult: "fail",
            gameResultRaw: "fail",
            spiritResult: "none",
            hand: this.hand,
            poolOneType: this.hand.poolOne.type,
            poolOneName: this.hand.poolOne.name,
            poolOneFormula: this.hand.poolOne.toFoundry()[0].formula,
            poolOneSuccesses: this.hand.poolOne.successes(),
            poolOneResults: this.hand.poolOne.results(),
            poolTwoType: this.hand.poolTwo.type,
            poolTwoName: this.hand.poolTwo.name,
            poolTwoFormula: this.hand.poolTwo.toFoundry()[0].formula,
            poolTwoSuccesses: this.hand.poolTwo.successes(),
            poolTwoResults: this.hand.poolTwo.results(),
            poolSpiritName: this.hand.poolSpirit.name,
            poolSpiritType: this.hand.poolSpirit.type,
            poolSpiritFormula: this.hand.poolSpirit.toFoundry().length > 0 ? this.hand.poolSpirit.toFoundry()[0].formula : "",
            poolSpiritSuccesses: this.hand.poolSpirit.successes(),
            poolSpiritResults: this.hand.poolSpirit.results(),
        };
        if (result.successes >= 6) {
            result.gameResultRaw = "brilliant";
        }
        else if (result.successes >= 4) {
            result.gameResultRaw = "radiant";
        }
        else if (result.successes >= 2) {
            result.gameResultRaw = "luminous";
        }
        if (result.successes > 0 && this.hand.poolSpirit.successes() > 0) {
            if (result.successes === 6) {
                result.spiritResult = "legendary";
            }
            else if (result.successes % 2 === 0) {
                result.spiritResult = "pool";
            }
            else {
                result.spiritResult = "flare";
                result.successes += 1;
            }
        }
        if (result.successes >= 6) {
            if (result.spiritResult === "legendary") {
                result.gameResult = "legendary";
            }
            else {
                result.gameResult = "brilliant";
            }
        }
        else if (result.successes >= 4) {
            result.gameResult = "radiant";
        }
        else if (result.successes >= 2) {
            result.gameResult = "luminous";
        }
        return result;
    }
}
export class OverlightCombatTest {
    constructor(hand) {
        this.hand = hand;
    }
    result() {
        this.hand.roll();
        const result = {
            damage: this.hand.successes(),
            fury: this.hand.poolSpirit.successes() > 0,
            successesRaw: this.hand.successes(),
            gameResult: "fail",
            gameResultRaw: "fail",
            spiritResult: "none",
            hand: this.hand,
            poolOneType: this.hand.poolOne.type,
            poolOneName: this.hand.poolOne.name,
            poolOneFormula: this.hand.poolOne.toFoundry()[0].formula,
            poolOneSuccesses: this.hand.poolOne.successes(),
            poolOneResults: this.hand.poolOne.results(),
            poolTwoType: this.hand.poolTwo.type,
            poolTwoName: this.hand.poolTwo.name,
            poolTwoFormula: this.hand.poolTwo.toFoundry()[0].formula,
            poolTwoSuccesses: this.hand.poolTwo.successes(),
            poolTwoResults: this.hand.poolTwo.results(),
            poolSpiritName: this.hand.poolSpirit.name,
            poolSpiritType: this.hand.poolSpirit.type,
            poolSpiritFormula: this.hand.poolSpirit.toFoundry().length > 0 ? this.hand.poolSpirit.toFoundry()[0].formula : "",
            poolSpiritSuccesses: this.hand.poolSpirit.successes(),
            poolSpiritResults: this.hand.poolSpirit.results(),
        };
        if (result.damage > 0) {
            result.gameResult = "success";
            result.gameResultRaw = "success";
        }
        return result;
    }
}
export class OverlightOpenTest {
    constructor(hand) {
        this.hand = hand;
    }
    result() {
        const result = {
            highest: this.hand.highestResult().face,
            highestRaw: this.hand.highestResult().face,
            bonus: this.hand.poolSpirit.successes() > 0,
            hand: this.hand,
            spiritResult: "none",
            poolOneType: this.hand.poolOne.type,
            poolOneName: this.hand.poolOne.name,
            poolOneFormula: this.hand.poolOne.toFoundry()[0].formula,
            poolOneSuccesses: this.hand.poolOne.successes(),
            poolOneResults: this.hand.poolOne.results(),
            poolTwoType: this.hand.poolTwo.type,
            poolTwoName: this.hand.poolTwo.name,
            poolTwoFormula: this.hand.poolTwo.toFoundry()[0].formula,
            poolTwoSuccesses: this.hand.poolTwo.successes(),
            poolTwoResults: this.hand.poolTwo.results(),
            poolSpiritName: this.hand.poolSpirit.name,
            poolSpiritType: this.hand.poolSpirit.type,
            poolSpiritFormula: this.hand.poolSpirit.toFoundry().length > 0 ? this.hand.poolSpirit.toFoundry()[0].formula : "",
            poolSpiritSuccesses: this.hand.poolSpirit.successes(),
            poolSpiritResults: this.hand.poolSpirit.results(),
        };
        if (result.bonus) {
            result.highest += 1;
            result.spiritResult = "flare";
        }
        return result;
    }
}
export class OverlightChromaTest {
    constructor(hand) {
        this.hand = hand;
        this.skillTest = new OverlightSkillTest(hand);
    }
    result() {
        this.hand.roll();
        const result = {
            successes: this.hand.successes(),
            successesRaw: this.hand.successes(),
            gameResult: "fail",
            gameResultRaw: "fail",
            spiritResult: "none",
            cost: this.hand.poolSpirit.highestResult().face,
            hand: this.hand,
            poolOneType: this.hand.poolOne.type,
            poolOneName: this.hand.poolOne.name,
            poolOneFormula: this.hand.poolOne.toFoundry()[0].formula,
            poolOneSuccesses: this.hand.poolOne.successes(),
            poolOneResults: this.hand.poolOne.results(),
            poolTwoType: this.hand.poolTwo.type,
            poolTwoName: this.hand.poolTwo.name,
            poolTwoFormula: this.hand.poolTwo.toFoundry()[0].formula,
            poolTwoSuccesses: this.hand.poolTwo.successes(),
            poolTwoResults: this.hand.poolTwo.results(),
            poolSpiritName: this.hand.poolSpirit.name,
            poolSpiritType: this.hand.poolSpirit.type,
            poolSpiritFormula: this.hand.poolSpirit.toFoundry().length > 0 ? this.hand.poolSpirit.toFoundry()[0].formula : "",
            poolSpiritSuccesses: this.hand.poolSpirit.successes(),
            poolSpiritResults: this.hand.poolSpirit.results(),
        };
        if (result.successes >= 6) {
            result.gameResult = "brilliant";
            result.gameResultRaw = "brilliant";
        }
        else if (result.successes >= 4) {
            result.gameResult = "radiant";
            result.gameResultRaw = "radiant";
        }
        else if (result.successes >= 2) {
            result.gameResult = "luminous";
            result.gameResultRaw = "luminous";
        }
        return result;
    }
}

//# sourceMappingURL=roll.js.map
