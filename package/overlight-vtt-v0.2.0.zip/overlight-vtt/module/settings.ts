export const registerSettings = function() {
	// Register any custom system settings here
}
