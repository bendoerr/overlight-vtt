export const OVERLIGHT_VIRTUES = ["wisdom", "logic", "compassion", "will", "vigor", "might"];

//# sourceMappingURL=virtue.js.map
