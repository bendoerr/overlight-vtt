export const OVERLIGHT_SKILLS = [
    "folklore",
    "intuition",
    "perception",
    "windlore",
    "machinery",
    "science",
    "beastways",
    "inspiration",
    "performance",
    "craft",
    "persuasion",
    "resolve",
    "athletics",
    "blades",
    "survival",
    "brawl",
    "resistance",
];

//# sourceMappingURL=skill.js.map
